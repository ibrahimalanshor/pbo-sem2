/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo_m010_5210411008;

/**
 *
 * @author ibrahimalanshor
 */
public class NimHarusPositifException extends Exception {

    @Override
    public String getMessage() {
        return "Inputan NIM harus bilangan positif"; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    
    
}
