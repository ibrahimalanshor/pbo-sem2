package pbo_m010_5210411008;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Mahasiswa {
    private String nama;
    private String nim;
    private int angkatan;
    private String smt;
    private String prodi;
    private int sks;
    
public Mahasiswa(){
    }
    
public Mahasiswa(String nama, String nim, int angkatan, String smt, String prodi, int sks){
    this.nama = nama;
    this.nim = nim;
    this.angkatan = angkatan;
    this.smt = smt;
    this.prodi = prodi;
    this.sks = sks;
    }
//setter

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public void setAngkatan(int angkatan) {
        this.angkatan = angkatan;
    }

    public void setSmt(String smt) {
        this.smt = smt;
    }

    public void setProdi(String prodi) {
        this.prodi = prodi;
    }

    public void setSks(int sks) {
        this.sks = sks;
    }

//    Getter
    public String getNama() {
        return nama;
    }

    public String getNim() {
        return nim;
    }

    public int getAngkatan() {
        return angkatan;
    }

    public String getSmt() {
        return smt;
    }

    public String getProdi() {
        return prodi;
    }

    public int getSks() {
        return sks;
    }
    
//    Cetak info
    public String cetakInfo(){
        StringBuilder sb = new StringBuilder();
        sb.append("* * * * * INFO MAHASISWA * * * * *");
        sb.append("\nNama\t: "+getNama());
        sb.append("\nNIM\t: "+getNim());
        sb.append("\nAngkatan\t: "+getAngkatan());
        sb.append("\nSemester\t: "+getSmt());
        String prodi = "";
        if (getProdi() == "1"){
            prodi = ("Teknik Informatika");
            }
        else {
            prodi = ("Teknik Industri");
        }
        sb.append("\nProdi\t: "+prodi);
        sb.append("\nSKS\t: "+getSks()+"\n");
        
        return sb.toString();
    }
    
    public String hitungSPPTetap(){
        int idx = 0;
        if (this.getProdi() == "1"){
            idx = 1;
        }
        else {
            idx = 2;
        }
        double spp;
        switch (idx) {
            case 1:
                if (getAngkatan() <= 2019){
                    spp = 2050;

                }
                else if (getAngkatan() == 2020){
                    spp = 2150;
                }
                
                else{
                    spp = 2250;
                }
                break;
                
            case 2:
                if (getAngkatan() <= 2019){
                    spp = 1650;

                }
                else if (getAngkatan() == 2020){
                    spp = 1700;
                }
                
                else{
                    spp = 1750;
                }
                break;
            default:
                throw new AssertionError();
        }

       return Double.toString(spp);
    }
    
    public String hitungSPPVariabel(){
        int idx = 0;
        if (this.getProdi() == "1"){
            idx = 1;
        }
        else {
            idx = 2;
        }
        double sppVariable;
        switch (idx) {
            case 1:
                if (getAngkatan() <= 2019){
                    sppVariable = getSks()* 240.000;
                }
                else if (getAngkatan() == 2020){  
                    sppVariable = getSks()* 245.000;
                }               
                else{                    
                    sppVariable = getSks()* 250.000;
                }
                break;
                
            case 2:
                if (getAngkatan() <= 2019){
                    sppVariable = getSks()* 170.000;

                }
                else if (getAngkatan() == 2020){
                    sppVariable = getSks()* 180.000;
                }
                
                else{
                    sppVariable = getSks()* 190.000;
                }
                break;
            default:
                throw new AssertionError();
        }
        
        return Double.toString(sppVariable);
    }
    
    public String hitungTotalSPP(){ 
        double sppTetap = Double.parseDouble(hitungSPPTetap());
        double sppVar = Double.parseDouble(hitungSPPVariabel());
        double totSPP = (sppTetap + sppVar);
        
        return Double.toString(totSPP);
    }
    
    public String cetakTagihanSPP(){
        StringBuilder sb = new StringBuilder();
        sb.append("\n============DATA TAGIHAN MAHASISWA =================");
        sb.append("\nSPP Tetap	: Rp. "+ hitungSPPTetap()+"00");
        sb.append("\nSPP Variabel	: Rp. "+ hitungSPPVariabel()+".00");
        sb.append("\nTotal Tagihan SPP Semester ini: Rp. "+ hitungTotalSPP()+"00");
        return sb.toString();
    } 
    
    public String AutoSemestert(){
        int angkatan = getAngkatan();
        String sks = "";
        if (angkatan == 2018){
            sks = ("VIII");
        }
        else if (angkatan == 2019){
            sks=("VI");
        }
        else if (angkatan == 2020){
            sks=("IV");
        }
        if (angkatan == 2021){
            sks=("II");
        }
        
        return sks.toString();
        
    }
          
}
